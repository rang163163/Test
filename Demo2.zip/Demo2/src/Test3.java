import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class Test3 {
	public static void main(String[] args) {
		final JFrame frame = new JFrame();
		frame.setSize(500, 500);
		
		frame.setLayout(null);
		JButton btn = new JButton("��ť");
		btn.setBounds(10, 10, 100,30);
		
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				String s=JOptionPane.showInputDialog(null, "������", "���", 0) ;
				System.out.println(s);
			}
		});
		
		frame.add(btn);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}		

}
