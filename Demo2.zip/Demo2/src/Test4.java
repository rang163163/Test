import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class Test4 {
	public static void main(String[] args) {
        JFrame jf = new JFrame("�û���¼");
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setSize(400,200);
        
        
        JPanel panel01 = new JPanel();
        
        panel01.add(new JLabel("�û���"));
        panel01.add(new JTextField(10));
       
       
        JPanel panel02 = new JPanel();
        panel02.add(new JLabel("��   ��"));
        panel02.add(new JPasswordField(10));

      
        JPanel panel03 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel03.add(new JButton("��¼"));
        panel03.add(new JButton("ע��"));

        
        Box vBox = Box.createVerticalBox();
        
        vBox.add(panel01);
        vBox.add(panel02);
        vBox.add(panel03);
       
        jf.setContentPane(vBox);

       
        jf.setLocationRelativeTo(null);
        jf.setVisible(true);
    }

}
