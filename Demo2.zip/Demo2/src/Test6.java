import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerListener;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Test6 {
	public static void main(String[] args) {
        JFrame jf = new JFrame("���Դ���");
        jf.setSize(300, 300);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setLocationRelativeTo(null);

        
        JSplitPane splitPane = new JSplitPane();

       
        ImageIcon image = new ImageIcon("./src/open.gif");
		
		JLabel jimage = new JLabel();
		jimage.setIcon(image);
		JLabel jimage1 = new JLabel();
		jimage1.setIcon(image);
        splitPane.setLeftComponent(jimage);
       
        splitPane.setRightComponent(jimage1);
       

        
        splitPane.setOneTouchExpandable(true);
        splitPane.setOrientation(0);
        splitPane.setDividerSize(20);
        
        splitPane.setContinuousLayout(true);
               
        
       
       
        splitPane.setDividerLocation(120);
      
       
        jf.setContentPane(splitPane);
        jf.setVisible(true);
    }

	


}
