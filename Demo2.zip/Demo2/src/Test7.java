import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Test7 {
	public static void main(String[] args) {
        JFrame jf = new JFrame("");
        jf.setSize(500, 400);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setLocationRelativeTo(null);

        
        final JTabbedPane tabbedPane = new JTabbedPane();

        ImageIcon image=new ImageIcon("./src/bb.jpg");
        ImageIcon image1=new ImageIcon("./src/1.jpg");
        ImageIcon image2=new ImageIcon("./src/2.jpg");
        ImageIcon image3=new ImageIcon("./src/3.jpg");
		 
		
		image.setImage(image.getImage().getScaledInstance(10, 10, Image.SCALE_AREA_AVERAGING));
        
        tabbedPane.addTab("����ͼƬ1", image,createTextPanel(image1));
             tabbedPane.addTab("����ͼƬ2", image, createTextPanel(image2));
              tabbedPane.addTab("����ͼƬ3", image, createTextPanel(image3));


        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                System.out.println("��ǰѡ�е�ѡ�: " + tabbedPane.getSelectedIndex());
            }
        });

       
        tabbedPane.setSelectedIndex(1);

        jf.setContentPane(tabbedPane);
        jf.setVisible(true);
    }

   
    private static JComponent createTextPanel(ImageIcon image) {
        
        JPanel panel = new JPanel(new GridLayout(1, 1));
        image.setImage(image.getImage().getScaledInstance(300, 200, Image.SCALE_AREA_AVERAGING));
        
        JLabel label = new JLabel(image);
       
        label.setHorizontalAlignment(SwingConstants.CENTER);

       
        panel.add(label);

        return panel;
    }


}
