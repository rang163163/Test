import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class Test8 {
	public static void main(String[] args) throws Exception {
        final JFrame jf = new JFrame("���Դ���");
        jf.setSize(400, 400);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        
        JButton btn01 = new JButton("��Ϣ��");
        jf.add(btn01);
        btn01.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                JOptionPane.showMessageDialog(jf,"���", "��Ϣ����",JOptionPane.INFORMATION_MESSAGE
                );
            }
        });
        JButton btn02 = new JButton("�����");
        btn02.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                JOptionPane.showMessageDialog(jf,"�����", "��Ϣ����",JOptionPane.WARNING_MESSAGE
                );
            }
        });
        JButton btn03 = new JButton("ɾ���Ի���");
        btn03.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                int result = JOptionPane.showConfirmDialog(jf,"ɾ����","��ʾ",
JOptionPane.YES_NO_CANCEL_OPTION
                );
                System.out.println("ѡ����: " + result);
            }
        });
        JButton btn04 = new JButton("�ı������");
        btn04.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                String inputContent = JOptionPane.showInputDialog(jf,"�����������:","Ĭ������"
                );
                System.out.println("���������: " + inputContent);
            }
        });
        JButton btn05 = new JButton("������");
        btn05.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[] selectionValues = new Object[]{"����", "�Ϻ�", "֣��"};

                
                Object inputContent = JOptionPane.showInputDialog(
                        jf,
                        "ѡ��һ��: ",
                        "����",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        selectionValues,
                        selectionValues[0]
                );
                System.out.println("���������: " + inputContent);
            }
        });

        JButton btn06 = new JButton("��ť��");
        btn06.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                Object[] options = new Object[]{"����", "�Ϻ�", "֣��"};

                
                int optionSelected = JOptionPane.showOptionDialog(
                        jf,
                        "����һ��",
                        "�Ի������",
                        JOptionPane.YES_NO_CANCEL_OPTION,
                        JOptionPane.ERROR_MESSAGE,
                        null,
                        options,    
                        options[0]
                );

                if (optionSelected >= 0) {
                    System.out.println("����İ�ť: " + options[optionSelected]);
                }
            }
        });



     Box vbox=Box.createVerticalBox();
     vbox.add(btn01);
     vbox.add(btn02);
     vbox.add(btn03);
     vbox.add(btn04);
   
	vbox.add(btn05);
     vbox.add(btn06);
     JPanel panel = new JPanel();
     panel.add(vbox);

     jf.setContentPane(panel);
          jf.setVisible(true);
}}
