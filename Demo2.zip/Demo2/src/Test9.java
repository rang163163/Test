import java.awt.Component;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class Test9 {
	public static void main(String[] args) throws Exception {
        final JFrame j = new JFrame("����");
        j.setSize(300, 300);
        j.setLocationRelativeTo(null);
        j.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        
                
           JButton bt = new JButton("JDialog�Ի���");
        bt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCustom(j, j);
            }
        });

        JPanel pane = new JPanel();
        pane.add(bt);

        j.setContentPane(pane);
        j.setVisible(true);
    }

    
    private static void showCustom(Frame f1, Component f2) {
        
        final JDialog log = new JDialog(f1, "JDialog", true);
       
        log.setSize(100, 150);
        
        log.setResizable(false);
        
        log.setLocationRelativeTo(f2);

        
        JLabel messageLabel = new JLabel("����");

       
        JButton Btn = new JButton("ȷ��");
        Btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                log.dispose();
            }
        });

        
        JPanel panel = new JPanel();

        
        panel.add(messageLabel);
        panel.add(Btn);

        
        log.setContentPane(panel);
       
        log.setVisible(true);
    }


}
