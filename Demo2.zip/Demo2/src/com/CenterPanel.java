package com;

import java.awt.Panel;

public class CenterPanel extends Panel {

}
