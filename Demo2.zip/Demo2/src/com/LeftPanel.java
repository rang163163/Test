package com;

import java.awt.BorderLayout;
import java.awt.Panel;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

public class LeftPanel extends Panel{
         private  DefaultMutableTreeNode de1;
         private  DefaultMutableTreeNode de11;
         private  DefaultMutableTreeNode de12;
         private  DefaultMutableTreeNode de13;
         public LeftPanel() {
				initComponents();
				setVisible(true);
			}
		public void initComponents() {
			
			de1=new DefaultMutableTreeNode("����ͼƬ");
			de11=new DefaultMutableTreeNode("����ͼƬ1");
			de12=new DefaultMutableTreeNode("����ͼƬ2");
			de13=new DefaultMutableTreeNode("����ͼƬ3");
			de1.add(de11);
			de1.add(de12);
			de1.add(de13);
			
			JTree jt=new JTree(de1);
			
	        jt.setEditable(true);
			jt.addTreeSelectionListener(new TreeSelectionListener() {
				
				@Override
				public void valueChanged(TreeSelectionEvent e) {
					
					MyFrame main = SwingUtil.getMainframe();
					  
						
					    int aa1=jt.getRowForPath(e.getPath());
					   System.out.println(aa1);
						CenterPanel jpCenter = main.getCenterPanel();
						
						
						jpCenter.removeAll();
						
						ImageIcon image1=new ImageIcon("./src/"+aa1+".jpg");
						JLabel labe = new JLabel(image1);
						jpCenter.setLayout(new BorderLayout());
						jpCenter.add(labe, BorderLayout.CENTER);
						
						
						jpCenter.revalidate();
						
						jpCenter.repaint();
				}
			});
			add(jt);
		}
}
