package com;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyFrame extends JFrame{

	
	public static void main(String[] args) {
		new MyFrame();
	}
	private CenterPanel centerpanel=null;
	private LeftPanel leftpanel=null;
	public MyFrame()
	{
		setTitle("ͼƬ����");
		setSize(700,600);
		FistleftPanel();
		FistcenterPanel();
		setVisible(true);
		SwingUtil.setMainframe(this);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public CenterPanel getCenterPanel() {
		return centerpanel;
	}
	public void FistcenterPanel() {
		centerpanel = new CenterPanel();
		 ImageIcon image1=new ImageIcon("./src/1.jpg");
		JLabel label = new JLabel(image1);
		centerpanel.add(label);
		this.add(centerpanel, BorderLayout.CENTER);
		
	}

	public void FistleftPanel() {
		
		leftpanel = new LeftPanel();
		leftpanel.setPreferredSize(new Dimension(180,550));
		this.add(leftpanel,BorderLayout.WEST);
		
	}

	
}
