package com;


	public class SwingUtil {
		public static MyFrame mainframe;
		public static MyFrame getMainframe() {
			
			return mainframe;
		}
		public static void setMainframe(MyFrame mainframe) {
			
			   SwingUtil.mainframe = mainframe;
		}
	}

